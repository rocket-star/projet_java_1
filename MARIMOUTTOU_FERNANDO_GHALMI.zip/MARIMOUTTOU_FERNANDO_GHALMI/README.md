# projet_java_1

JAVA VERSION : 8

IDE: Ce projet à été réalisé avec Eclipse (en effet nous avons rencontrés quelques difficultés pour installer NetBeans sur Mac).

DATA BASE: N'utilisant pas NetBeans nous avons du modifier la syntaxe du script SQL pour le faire fonctionner sur SqlPlus.

BONUS : Il a été fait en totalité, pour la question 2) nous avons un fichier "connexion.txt" qui contient: url,username,password
